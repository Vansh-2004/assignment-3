# Introduction
> 3D

That was an interesting experience of using 3D objects in an HTML page. I found out later that it would have been better to use "Three.js" instead of "spline". Anyway, I need some knowledge for that. "Spline" just helped me with 3D modeling without any coding.

> Problems of "spline"

However, there are some problems with "spline". It is literally impossible to make spline objects responsive. I haven't found any solution for that. In fact, I am talking about my project because I have used a specific way of object placement. But I would still recommend you to learn "Three.js" instead

# Color selection
> Billboard with 3D model

For 3D model of the candy I have used Analogous color scheme
this allows the candy to look beautiful and rich, for the backgroud 
as well as for shadows i have choosen Complementary scheme, this helps to play with contrast.

> Main page and backgound

No doubt dark theme, and for background(bg) some cubic candy images, they are pink that also allows as to make them contrast on the bg, and they are related to main idea. Cards are transparent make cool effect and you can see bg ass well, and to make it more readble there are some linear-gradient on hover.

> colors was used

Candy (colors taken  form 'spline')
 - 'FE7ABA'
 - 'FFB57C'
   
Backgound of candy
 - '1414FF'
 - 'FFA514'
   
Website backgound(colors taken from VS)
 - '#212529'
   
Linear-gradient
 - 'rgb(255, 255, 255)'
 - 'rgb(238, 214, 169)'
 - 'rgb(238, 169, 169)'
 - 'rgb(122, 122, 215)'
